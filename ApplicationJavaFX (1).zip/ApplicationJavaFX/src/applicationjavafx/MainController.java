// Pacote da aplicação-----
package applicationjavafx;
//-------------------------

// Importando bibliotecas-----------------------------
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
//------------------------------------------------------

public class MainController implements Initializable {
    
    //declarando os elementos do javaFX------------------------------------
    @FXML
    private TextField tfIdDepartamento;
    @FXML
    private TextField tfSiglaDepartamento;
    @FXML
    private TextField tfNomeDepartamento;
    @FXML
    private TextField tfTelefoneDepartamento;

    @FXML
    private TableView<Books> tvBooks;
    @FXML
    private TableColumn<Books, Integer> colIdDepartamento;
    @FXML
    private TableColumn<Books, String> colSiglaDepartamento;
    @FXML
    private TableColumn<Books, String> colNomeDepartamento;
    @FXML
    private TableColumn<Books, Integer> colTelefoneDepartamento;
    
    @FXML
    private Button btnInserirDepartamento;
    @FXML
    private Button btnAtualizarDepartamento;
    @FXML
    private Button btnDeletarDepartamento;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {        
        
        //Verificando a condição dos botões e chamando as funções--
        if(event.getSource() == btnInserirDepartamento){
            insertRecord();
        }else if (event.getSource() == btnAtualizarDepartamento){
            updateRecord();
        }else if(event.getSource() == btnDeletarDepartamento){
            deleteButton();
        }
        //---------------------------------------------------------
            
    }
    //-----------------------------------------------------------------
    
    //gerando a conexão com o banco de dados ------------------------------------------------------------
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showBooks();
    }
    
    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root","");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
    //----------------------------------------------------------------------------------------------------
    
    //tranformando um arraylist para um observableList-----------------------------------------------------------------------
    public ObservableList<Books> getBooksList(){
        ObservableList<Books> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM books";
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Books books;
            while(rs.next()){
                books = new Books(rs.getInt("id"), rs.getString("sigla"), rs.getString("nome"), rs.getInt("telefone"));
                bookList.add(books);
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return bookList;
    }
    //-----------------------------------------------------------------------------------------------------------------------
    
    //colocando os valores na tabela----------------------------------------------------------------------------
    public void showBooks(){
        ObservableList<Books> list = getBooksList();
        
        colIdDepartamento.setCellValueFactory(new PropertyValueFactory<Books, Integer>("id"));
        colSiglaDepartamento.setCellValueFactory(new PropertyValueFactory<Books, String>("sigla"));
        colNomeDepartamento.setCellValueFactory(new PropertyValueFactory<Books, String>("nome"));
        colTelefoneDepartamento.setCellValueFactory(new PropertyValueFactory<Books, Integer>("telefone"));
        
        tvBooks.setItems(list);
    }
    //------------------------------------------------------------------------------------------------------------
    
    //funcões dos botões-----------------------------------------------------------------------------------------------------------------------------------------------------
    private void insertRecord(){
        String query = "INSERT INTO books VALUES (" + tfIdDepartamento.getText() + ",'" + tfSiglaDepartamento.getText() + "','" + tfNomeDepartamento.getText() + "',"
                + tfTelefoneDepartamento.getText() + ")";
        executeQuery(query);
        showBooks();
    }
    private void updateRecord(){
        String query = "UPDATE  books SET sigla  = '" + tfSiglaDepartamento.getText() + "', nome = '" + tfNomeDepartamento.getText() + "', telefone = " +
                tfTelefoneDepartamento.getText() + " WHERE id = " + tfIdDepartamento.getText() + "";
        executeQuery(query);
        showBooks();
    }
    private void deleteButton(){
        String query = "DELETE FROM books WHERE id =" + tfIdDepartamento.getText() + "";
        executeQuery(query);
        showBooks();
    }
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
        
    
}