package applicationjavafx;

public class Books {
    private int id;
    private String sigla;
    private String nome;
    private int telefone;

    public Books(int id, String sigla, String nome, int telefone) {
        this.id = id;
        this.sigla = sigla;
        this.nome = nome;
        this.telefone = telefone;
    }

    public int getId() {
        return id;
    }

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }

    public int getTelefone() {
        return telefone;
    }
    
}
